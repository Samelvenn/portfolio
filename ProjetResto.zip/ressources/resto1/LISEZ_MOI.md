# Ancienne base resto1

Ces deux scripts d’origine servent d’abord à la **comparaison du modèle**. Le site utilise **resto2**.

Pour la comparaison de l’itération 1, ouvrir `resto1_structure_et_contenu_v_initiale.sql` dans l’éditeur suffit ; aucun import n’est obligatoire.

Pour l’approfondissement facultatif, utiliser une copie dédiée et un compte administrateur local. Le script `resto1_create_bdd_et_util_v_initiale.sql` contient un `CREATE USER resto_util` qui entre en conflit si le compte a déjà été créé pour resto2 : ne pas lancer ce script aveuglément.

Une préparation possible avec l’enseignant, si resto1 n’existe pas :

```sql
CREATE DATABASE resto1 DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

Puis importer `resto1_structure_et_contenu_v_initiale.sql` avec le compte administrateur. Cette variante ne recrée pas le compte applicatif. Le script sélectionne `resto1` : vérifier ce nom avant import. Si resto1 existe déjà, examiner son contenu et choisir une copie de travail avec l’enseignant. Ne pas importer la structure resto1 dans resto2.

Les scripts sont conservés tels que fournis, sans corrigé de migration.
