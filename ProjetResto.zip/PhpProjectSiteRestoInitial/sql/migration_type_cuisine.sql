USE resto2;

CREATE TABLE IF NOT EXISTS cuisine(idC INT PRIMARY KEY AUTO_INCREMENT, libelle VARCHAR(50));

CREATE TABLE IF NOT EXISTS restaurant_cuisine(idR bigint, idC int, PRIMARY KEY (idR, idC));

INSERT INTO cuisine(libelle) VALUES ("sud ouest"), ("japonaise"), ("orientale"), ("fastfood"), ("vegetarienne"), ("vegan"), ("crepe"), ("sandwich"), ("tartes"), ("viande"), ("grillade");

INSERT INTO restaurant_cuisine(idR, idC) VALUES(1, 10), (1, 11), (1, 1), (2, 10), (2, 11), (3, 2), (3, 5), (3, 6), (4, 7), (5, 3), (5, 4), (6, 1), (6, 10), (6, 8), (7, 1), (7, 4), (8, 3), (9, 10), (9, 11), (10, 8), (10, 9), (10, 4), (11, 3), (11, 11);

ALTER TABLE cuisine MODIFY idC INT NOT NULL;

ALTER TABLE restaurant_cuisine MODIFY idR INT NOT NULL, MODIFY idC INT NOT NULL;

ALTER TABLE restaurant_cuisine ADD CONSTRAINT fk_cuisine FOREIGN KEY (idC) REFERENCES cuisine(idC);

ALTER TABLE restaurant_cuisine MODIFY COLUMN idR BIGINT;

ALTER TABLE restaurant_cuisine ADD CONSTRAINT fk_restaurant FOREIGN KEY (idR) REFERENCES resto(idR);

SELECT r.nomR, c.libelle FROM resto as r INNER JOIN restaurant_cuisine ON r.idR = restaurant_cuisine.idR INNER JOIN cuisine as c ON c.idC = restaurant_cuisine.idC WHERE c.libelle = "viande" OR c.libelle = "japonaise";

