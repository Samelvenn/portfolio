'''
Docstring for calcul_inazuma
V1
04/12/2025
Le but est de calculer les valeurs des stats d'un joueur du jeu inazuma eleven 
'''

#La première class permet de créer un joueur avec toutes ses valeurs statistiques.
class Joueur:
    def __init__(self, nom, frappe, dribble, defense, vitesse):
        self.nom = nom
        self.frappe = frappe
        self.dribble = dribble
        self.defense = defense
        self.vitesse = vitesse
    
    def stat_frappe(self):
        print(f"La frappe de {self.nom} est de {self.frappe}.")
    
    def stat_défense(self):
        print(f"La défense de {self.nom} est de {self.defense}.")

    def stat_vitesse(self):
        print(f"La vitesse de {self.nom} est de {self.vitesse}.")

    def stat_dribble(self):
        print(f"Le dribble de {self.nom} est de {self.dribble}.")
    
    def stat_globale(self):
        print(f"Le joueur {self.nom} a pour statistiques : {self.frappe} en frappe, {self.defense} en défense, {self.vitesse} en vitesse et {self.dribble} en dribble.")


#La seconde class permet d'ajouter des joueurs à leur équipe. 
class Equipe:
    def __init__(self, nom_equipe):
        self.nom_equipe = nom_equipe
        self.joueurs = []
    
    def ajouter_joueurs(self,joueur):
        self.joueurs.append(joueur)

    def afficher_joueurs_equipe(self):
        print(f"L'équipe {self.nom_equipe} est composée des joueurs suivants :")
        for joueur in self.joueurs:
            print(f"- {joueur.nom}")
            
    def afficher_stat_equipe(self):
        print(f"Les statistqiues des joueurs de l'équipe {self.nom_equipe} sont les suivantes :")
        for joueur in self.joueurs:
            print(f"- {joueur.nom} : {joueur.frappe} en frappe, {joueur.defense} en défense, {joueur.vitesse} en vitesse, {joueur.dribble} en dribble")
        
#Une class qui permet de comparer les statitistiques des joueurs. 
class Defi:
    def __init__(self):
        pass   

    def comparer_defense_deux_joueurs(self, joueur1, joueur2):
        """Compare la défense de deux joueurs"""
        if joueur1.defense > joueur2.defense:
            print(f"La défense de {joueur1.nom} ({joueur1.defense}) est supérieure à celle de {joueur2.nom} ({joueur2.defense})")
        elif joueur1.defense < joueur2.defense:
            print(f"La défense de {joueur2.nom} ({joueur2.defense}) est supérieure à celle de {joueur1.nom} ({joueur1.defense})")
        else:
            print(f"{joueur1.nom} et {joueur2.nom} ont la même défense ({joueur1.defense})")

    def duel_tir(self, joueur1, joueur2):
        """On considère que le joueur 1 est le joueur qui attaque"""
        if joueur1.frappe> joueur2.defense:
            print(f"But !! {joueur1.nom} a marqué contre {joueur2.nom}")
        else:
            print(f"Le gardien {joueur2.nom} arrête le ballon")

    def duel_dribble(self, joueur1, joueur2):
        """On considère que le joueur 1 est le joueur qui attaque, on considera également que le défenseur a l'avantage si il y a égalité"""
        if joueur1.dribble> joueur2.defense:
            print(f"L'attaquant {joueur1.nom} a gagné le duel contre {joueur2.nom}")
        else:
            print(f"Le défenseur {joueur2.nom} a gagné le duel contre {joueur1.nom}")


"""
Byron=Joueur("Byron", 110, 100, 100, 100)
Byron.stat_globale()
Raimon=Equipe("Raimon")
Zeus=Equipe("Zeus")
Raimon.ajouter_joueurs(Joueur("Axel", 100, 50, 50, 50))
Raimon.ajouter_joueurs(Joueur("Mark", 50, 30, 100, 30))
Raimon.ajouter_joueurs(Joueur("Jack", 60, 70, 70, 50))
Raimon.afficher_joueurs_equipe()
Zeus.ajouter_joueurs(Byron)
Zeus.afficher_stat_equipe()
Raimon.afficher_stat_equipe()
Defi1 = Defi()
Defi1.comparer_defense_deux_joueurs(Joueur("Axel", 100, 50, 50, 50), Joueur("Mark", 50, 30, 100, 30))
Defi1.duel_dribble(Joueur("Axel", 100, 50, 50, 50), Joueur("Mark", 50, 30, 100, 30))
Defi1.duel_tir(Joueur("Axel", 100, 50, 50, 50), Joueur("Mark", 50, 30, 100, 30))
Defi1.duel_tir(Byron,Joueur("Mark", 50, 30, 100, 30))
"""







