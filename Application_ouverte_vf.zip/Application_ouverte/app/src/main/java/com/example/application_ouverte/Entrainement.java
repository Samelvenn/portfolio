package com.example.application_ouverte;

public class Entrainement {
    private String coach;
    private String balle;
    private int nbParticipants;
    private int duree;
    private String cours;

    public Entrainement(String coach, String balle, int nbParticipants, int duree, String cours) {
        if (coach == null || coach.trim().isEmpty())
            throw new IllegalArgumentException("Coach invalide");

        if (balle == null || balle.trim().isEmpty())
            throw new IllegalArgumentException("Balle invalide");

        if (duree < 30 || duree > 120)
            throw new IllegalArgumentException("Durée invalide");

        if (nbParticipants < 1 || nbParticipants > 6)
            throw new IllegalArgumentException("Nombre participants invalide");

        if (!cours.equals("Cours A") && !cours.equals("Cours B") && !cours.equals("Cours C"))
            throw new IllegalArgumentException("Cours invalide");

        this.coach = coach;
        this.balle = balle;
        this.nbParticipants = nbParticipants;
        this.duree = duree;
        this.cours = cours;
    }

    public String getResume() {
        return "Coach: " + coach + " - " + "Balle: " + balle + " - " + "Duree: " + duree + " - " + "Nombre participants: " + nbParticipants + " - " + "Cours: " + cours;
    }

    public String getCoach() {
        return coach;
    }

    public String getBalle() {
        return balle;
    }

    public int getDuree() {
        return duree;
    }

    public int getNbParticipants() {
        return nbParticipants;
    }

    public String getCours() {
        return cours;
    }

}