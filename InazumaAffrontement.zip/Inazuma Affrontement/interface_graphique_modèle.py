import tkinter as tk
from tkinter import messagebox, ttk


from calcul_inazuma import Joueur, Equipe, Defi


Raimon = Equipe("Raimon")
Royal = Equipe("Royal Academy")
Zeus = Equipe("Zeus")
Tempete = Equipe("Tempête des gémeaux")
Genesis = Equipe("Genesis")
Gigantes = Equipe("Little Gigantes")
Inazuma_Japon = Equipe("Inazuma Japon")


Mark = Joueur("Mark", 50, 30, 100, 40)
Axel = Joueur("Axel", 50, 30, 100, 40)
Jack = Joueur("Jack", 50, 30, 100, 40)
Tod = Joueur("Tod", 50, 30, 100, 40)
Nathan = Joueur("Nathan", 50, 30, 100, 40)
Jim = Joueur("Jim", 50, 30, 100, 40)
Timmy = Joueur("Timmy", 50, 30, 100, 40)
Willy = Joueur("Willy", 50, 30, 100, 40)
Sam = Joueur("Sam", 50, 30, 100, 40)
Steve = Joueur("Steve", 50, 30, 100, 40)
Kevin = Joueur("Kevin", 50, 30, 100, 40)
Max = Joueur("Max", 50, 30, 100, 40)
Jude = Joueur("Jude", 100, 100, 50, 50)


Raimon.ajouter_joueurs(Mark)
Raimon.ajouter_joueurs(Jude)
Raimon.ajouter_joueurs(Axel)
Raimon.ajouter_joueurs(Jack)
Raimon.ajouter_joueurs(Tod)
Raimon.ajouter_joueurs(Nathan)
Raimon.ajouter_joueurs(Jim)
Raimon.ajouter_joueurs(Timmy)
Raimon.ajouter_joueurs(Willy)
Raimon.ajouter_joueurs(Sam)
Raimon.ajouter_joueurs(Steve)
Raimon.ajouter_joueurs(Kevin)
Raimon.ajouter_joueurs(Max)


TEAMS = [Raimon, Royal, Zeus, Tempete, Genesis, Gigantes, Inazuma_Japon]


ALL_PLAYERS = []
for team in TEAMS:
    for p in team.joueurs:
        ALL_PLAYERS.append(p)

class GUI:
    def __init__(self, root):
        self.root = root
        root.title("Inazuma Affrontement - Interface Graphique")
        root.geometry("800x420")

        
        left_frame = ttk.Frame(root, padding=(10, 10))
        left_frame.pack(side=tk.LEFT, fill=tk.Y)

        ttk.Label(left_frame, text="Equipes").pack()
        self.team_listbox = tk.Listbox(left_frame, height=15)
        self.team_listbox.pack()
        for team in TEAMS:
            self.team_listbox.insert(tk.END, team.nom_equipe)
        self.team_listbox.bind("<<ListboxSelect>>", self.on_team_select)

        
        middle_frame = ttk.Frame(root, padding=(10, 10))
        middle_frame.pack(side=tk.LEFT, fill=tk.Y)

        ttk.Label(middle_frame, text="Joueurs (Equipe sélectionnée)").pack()
        self.player_listbox = tk.Listbox(middle_frame, height=15)
        self.player_listbox.pack()
        self.player_listbox.bind("<<ListboxSelect>>", self.on_player_select)

        
        right_frame = ttk.Frame(root, padding=(10, 10))
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        ttk.Label(right_frame, text="Détails du joueur").pack()
        self.details_text = tk.Text(right_frame, height=8, width=40)
        self.details_text.pack()

        ttk.Label(right_frame, text="Choisir un autre joueur pour les duels/comparaisons").pack()
        self.player2_combo = ttk.Combobox(right_frame, values=[p.nom for p in ALL_PLAYERS], state="readonly")
        self.player2_combo.pack()

        
        buttons_frame = ttk.Frame(right_frame, padding=(5, 5))
        buttons_frame.pack(fill=tk.X, pady=(10,0))

        ttk.Button(buttons_frame, text="Afficher stats", command=self.show_stats).pack(side=tk.LEFT, padx=2)
        ttk.Button(buttons_frame, text="Comparer défense", command=self.compare_defense).pack(side=tk.LEFT, padx=2)
        ttk.Button(buttons_frame, text="Duel Tir", command=self.duel_tir).pack(side=tk.LEFT, padx=2)
        ttk.Button(buttons_frame, text="Duel Dribble", command=self.duel_dribble).pack(side=tk.LEFT, padx=2)

        
        ttk.Label(right_frame, text="Résultat").pack()
        self.result_text = tk.Text(right_frame, height=6, width=40)
        self.result_text.pack()

    def on_team_select(self, event):
        selection = self.team_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        team = TEAMS[idx]
        self.player_listbox.delete(0, tk.END)
        for p in team.joueurs:
            self.player_listbox.insert(tk.END, p.nom)

    def on_player_select(self, event):
        self.show_stats()

    def _get_selected_player(self):
        sel = self.player_listbox.curselection()
        if not sel:
            messagebox.showwarning("Selection manquante", "Veuillez sélectionner un joueur dans la liste de gauche.")
            return None
        idx = sel[0]
        team_idx = self.team_listbox.curselection()
        if not team_idx:
            messagebox.showwarning("Equipe manquante", "Veuillez sélectionner une équipe en premier.")
            return None
        team = TEAMS[team_idx[0]]
        return team.joueurs[idx]

    def _get_player_by_name(self, name):
        for p in ALL_PLAYERS:
            if p.nom == name:
                return p
        return None

    def show_stats(self):
        joueur = self._get_selected_player()
        if not joueur:
            return
        self.details_text.delete(1.0, tk.END)
        self.details_text.insert(tk.END, f"Nom: {joueur.nom}\n")
        self.details_text.insert(tk.END, f"Frappe: {joueur.frappe}\n")
        self.details_text.insert(tk.END, f"Dribble: {joueur.dribble}\n")
        self.details_text.insert(tk.END, f"Défense: {joueur.defense}\n")
        self.details_text.insert(tk.END, f"Vitesse: {joueur.vitesse}\n")

    def compare_defense(self):
        j1 = self._get_selected_player()
        j2name = self.player2_combo.get()
        j2 = self._get_player_by_name(j2name)
        if not j1 or not j2:
            return
        d = Defi()
        # Capture prints by calling the method but instead of printing, build result
        if j1.defense > j2.defense:
            res = f"La défense de {j1.nom} ({j1.defense}) est supérieure à celle de {j2.nom} ({j2.defense})"
        elif j1.defense < j2.defense:
            res = f"La défense de {j2.nom} ({j2.defense}) est supérieure à celle de {j1.nom} ({j1.defense})"
        else:
            res = f"{j1.nom} et {j2.nom} ont la même défense ({j1.defense})"

        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, res)

    def duel_tir(self):
        j1 = self._get_selected_player()
        j2name = self.player2_combo.get()
        j2 = self._get_player_by_name(j2name)
        if not j1 or not j2:
            return
        if j1.frappe > j2.defense:
            res = f"But !! {j1.nom} a marqué contre {j2.nom}"
        else:
            res = f"Le gardien {j2.nom} arrête le ballon"
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, res)

    def duel_dribble(self):
        j1 = self._get_selected_player()
        j2name = self.player2_combo.get()
        j2 = self._get_player_by_name(j2name)
        if not j1 or not j2:
            return
        if j1.dribble > j2.defense:
            res = f"L'attaquant {j1.nom} a gagné le duel contre {j2.nom}"
        else:
            res = f"Le défenseur {j2.nom} a gagné le duel contre {j1.nom}"
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, res)


if __name__ == "__main__":
    root = tk.Tk()
    gui = GUI(root)
    root.mainloop()
