-- Itération 1 · I1-04 · Équipe : à compléter
-- Objectif : obtenir le nom des restaurants et la note attribuée
-- dans les critiques de l’utilisateur demandé dans le sujet.
USE resto2;

-- Écrire ici votre requête SELECT, puis la tester.
-- Reporter le résultat commenté dans docs/iteration1.md.
