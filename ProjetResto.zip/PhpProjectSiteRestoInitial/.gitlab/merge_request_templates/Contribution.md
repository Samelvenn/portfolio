## Pourquoi ?

Refs #NUMERO_A_REMPLACER

## Modifications

À compléter.

## Comment tester ?

- Préconditions :
- Actions et données :
- Résultats attendus :
- Résultats obtenus :

## Relecture

- [ ] Branche actualisée avec dev et retestée.
- [ ] Aucun secret personnel dans les modifications.
- [ ] Différences relues par un équipier.
- [ ] Branche testée par le relecteur.

Relecteur et remarque utile :

Après validation et fusion vers dev, fermer manuellement l’Issue.
