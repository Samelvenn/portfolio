package com.example.application_ouverte;

public class Joueur {
    private String Nom;
    private String Prenom;
    private int Age;
    private int NbEntrainement;

    public Joueur(String Nom, String Prenom, int Age, int NbEntrainement) {
        if (Nom == null || Nom.trim().isEmpty())
            throw new IllegalArgumentException("Nom invalide");

        if (Prenom == null || Prenom.trim().isEmpty())
            throw new IllegalArgumentException("Prenom invalide");

        if (Age < 5 || Age > 100)
            throw new IllegalArgumentException("Age invalide");

        if (NbEntrainement < 1 || NbEntrainement> 7)
            throw new IllegalArgumentException("Nombre entrainements invalide");

        this.Nom = Nom;
        this.Prenom = Prenom;
        this.Age = Age;
        this.NbEntrainement = NbEntrainement;

    }

    public String getJoueur() {
        return "Nom: " + Nom + " - " + "Prenom: " + Prenom + " - " + "Age: " + Age + " - " + "Nombre d'entrainement: " + NbEntrainement;
    }
    public String getNom() {
        return Nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public int getAge() {
        return Age;
    }

    public int getNbEntrainement() {
        return NbEntrainement;
    }

    public String estPro(int nbEntrainement) {
        if (nbEntrainement >= 5) {
            return "Le joueur est un professionnel.";
        }
        return "";
    }
}

