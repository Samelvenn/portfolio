CREATE DATABASE resto1 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'resto_util'@'localhost' IDENTIFIED BY 'secret';
GRANT ALL PRIVILEGES ON resto1.* TO 'resto_util'@'localhost';
