package com.example.application_ouverte;

import android.util.Log;
import java.util.ArrayList;

public class TestJoueur {
    public void executerTest() {
        Joueur joueur1 = new Joueur ("Vieux", "Bernard", 50, 2);
        Joueur joueur2 = new Joueur ("Vieux", "Mathilde", 52, 1);
        Joueur joueur3 = new Joueur ("Vieux", "Tom", 4, 2);
        ArrayList<Joueur> joueurs = new ArrayList<>();
        joueurs.add(joueur1);
        joueurs.add(joueur2);
        joueurs.add(joueur3);
        Log.d("application_ouverte", "Début des essais");
        //Afficher le résumé du joueur
        Log.d("application_ouverte",joueur1.getJoueur());
        for (Joueur joue : joueurs) {
            Log.d("application_ouverte", joue.getJoueur());
        }
        Log.d("application_ouverte", "Nombre de joueurs : " + joueurs.size());

        try {
            Joueur joueur5ans = new Joueur("Vieux", "Harry", 5,2);
            Log.d("application_ouverte","test 5ans " + joueur5ans.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: Age refusé (5ans)");
        }

        try {
            Joueur joueur3ans = new Joueur("Vieux", "Harry", 3,2);
            Log.d("application_ouverte","test 3 ans " + joueur3ans.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: Age refusé (3ans)");
        }

        try {
            Joueur joueur100ans = new Joueur("Vieux", "Harry", 100,2);
            Log.d("application_ouverte","test 100 ans " + joueur100ans.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: Age refusé (100ans)");
        }

        try {
            Joueur joueur101ans = new Joueur("Vieux", "Harry", 101,2);
            Log.d("application_ouverte","test 101 ans " + joueur101ans.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: Age refusé (101ans)");
        }

        try {
            Joueur joueur1entrainement = new Joueur("Vieux", "Harry", 10,1);
            Log.d("application_ouverte","test 1 entrainement" + joueur1entrainement.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: nbEntrainement refusé (1 entrainement)");
        }

        try {
            Joueur joueur0entrainement = new Joueur("Vieux", "Harry", 10,0);
            Log.d("application_ouverte","test 0 entrainement " + joueur0entrainement.getJoueur());
        } catch (IllegalArgumentException e) {
            Log.d("application_ouverte","Erreur: nbEntrainement refusé (0 entrainement)");
        }



    }


}
