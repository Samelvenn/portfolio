package com.example.application_ouverte;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ConsulterListeEntrainement extends AppCompatActivity {

    private RecyclerView recyclerViewEntrainement;
    private Button buttonRetourAccueilListe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_consulter_liste_entrainement);
        Entrainement entrainement1 = new Entrainement("Bernard","Rouge",5,60,"Cours A");
        Entrainement entrainement2 = new Entrainement("Tristan","Jaune",6,70,"Cours B");
        Entrainement entrainement3 = new Entrainement("Tristan", "Mousse",5,40,"Cours C");
        ArrayList<Entrainement> entrainements = new ArrayList<>();
        entrainements.add(entrainement1);
        entrainements.add(entrainement2);
        entrainements.add(entrainement3);
        RecyclerView liste = findViewById(R.id.RecyclerViewEntrainement);
        liste.setLayoutManager(new LinearLayoutManager( this));
        EntrainementAdapter adapter = new EntrainementAdapter(entrainements);
        liste.setAdapter(adapter);

        buttonRetourAccueilListe = findViewById(R.id.buttonRetourAccueilListe);
        buttonRetourAccueilListe.setOnClickListener(view -> finish());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}