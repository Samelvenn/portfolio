from calcul_inazuma import *
import sqlite3 

#Implémentation de la base de donnée
connexion = sqlite3.connect('Liste joueur.db')
cursor= connexion.cursor()
"""cursor.execute('SELECT Nom_equipe FROM Equipe ;')
rows= cursor.fetchall()
for row in rows:
    # `row` est un tuple renvoyé par sqlite (ex: ('Raimon',)).
    # Afficher uniquement la valeur sans parenthèses ni virgule :
    print(row[0])"""

cursor.execute("INSERT INTO Joueur(Id_joueur, Nom, frappe, dribble, defense, vitesse, Id_equipe) VALUES (1, 'Mark',50, 30, 100, 40, 1),(2, 'Axel',50, 30, 100, 40, 1),(3, 'Jack',50, 30, 100, 40, 1),(4, 'Tod',50, 30, 100, 40, 1),(5, 'Nathan',50, 30, 100, 40, 1),(6, 'Jim',50, 30, 100, 40, 1),(7, 'Timmy',50, 30, 100, 40, 1),(8, 'Willy',50, 30, 100, 40, 1),(9, 'Sam',50, 30, 100, 40, 1),(10, 'Steve',50, 30, 100, 40, 1),(11, 'Kevin',50, 30, 100, 40, 1),(12, 'Max',50, 30, 100, 40, 1),(13, 'Jude', 100, 100, 50, 50, 1);")



#On créé toutes les équipes que l'on souhaite avoir dans notre base de donnée
Raimon=Equipe("Raimon")
Royal=Equipe("Royal Academy")
Zeus=Equipe("Zeus")
Tempete=Equipe("Tempête des gémeaux")
Genesis=Equipe("Genesis")
Gigantes=Equipe("Little Gigantes")
Inazuma_Japon=Equipe("Inazuma Japon")

#On créé les joueurs de la base de donnée 
Mark=Joueur("Mark",50, 30, 100, 40)
Axel=Joueur("Axel",50, 30, 100, 40)
Jack=Joueur("Jack",50, 30, 100, 40)
Tod=Joueur("Tod",50, 30, 100, 40)
Nathan=Joueur("Nathan",50, 30, 100, 40)
Jim=Joueur("Jim",50, 30, 100, 40)
Timmy=Joueur("Timmy",50, 30, 100, 40)
Willy=Joueur("Willy",50, 30, 100, 40)
Sam=Joueur("Sam",50, 30, 100, 40)
Steve=Joueur("Steve",50, 30, 100, 40)
Kevin=Joueur("Kevin",50, 30, 100, 40)
Max=Joueur("Max",50, 30, 100, 40)
Jude=Joueur("Jude", 100, 100, 50, 50)

#On ajoute les joueurs à leur équipe
Raimon.ajouter_joueurs(Mark)
Raimon.ajouter_joueurs(Jude)
Raimon.ajouter_joueurs(Axel)
Raimon.ajouter_joueurs(Jack)
Raimon.ajouter_joueurs(Tod)
Raimon.ajouter_joueurs(Nathan)
Raimon.ajouter_joueurs(Jim)
Raimon.ajouter_joueurs(Timmy)
Raimon.ajouter_joueurs(Willy)
Raimon.ajouter_joueurs(Sam)
Raimon.ajouter_joueurs(Steve)
Raimon.ajouter_joueurs(Kevin)
Raimon.ajouter_joueurs(Max)
'''Raimon.afficher_joueurs_equipe()'''