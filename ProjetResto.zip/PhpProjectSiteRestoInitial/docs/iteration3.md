# Itération 3 — Bilan de l’équipe

# Ticket 07 - Evolution de la base de données

Nous allons effectuer une migration de la base de données pour pouvoir implémenter et utiliser les types de cuisine. Pour cela, nous allons créer une table cuisine qui va répertorié le référenciel fournit avec 11 types de cuisine. Il faut également créer une table de liaison.

Plan de migration : 

| Numéro | Phase | Action |
| --- | --- | --- |
| 1 | Se protéger | Sauvegarder la base de données avant toute modification |
| 2 | Construire | Créer la table cuisine avec les attributs id_cuisine et libelle |
| 3 | Construire | Créer la table d'association proposer entre cuisine et restaurant |
| 4 | Construire | Insertion des différents types de cuisine dans la table |
| 5 | Migrer les données | Remplir la table d'association entre les types de cuisine et les restaurants |
| 6 | Verrouiller | Passer la colonne id_cuisine de la table cuisine en NOT NULL |
| 7 | Verrouiller | Passer les colonnes id_cuisine et idR de la table restaurant_cuisine en NOT NULL |
| 8 | Verrouiller | Ajout de la contrainte de clé étrangère de la table proposer pour id_cuisine |
| 9 | Verrouiller | Ajout de la contrainte de clé étrangère de la table proposer pour idR |
| 10 | Prouver | Faire un état final en recherchant un restaurant et ses types de cuisine |

Requête préparée :

| Numéro | Action | Requêtes |
| 1 | Sauvegarder la base de données avant modification | mysqldump -u root -p resto2 > C:\Users\elven\bdd_avant_type_cuisine.sql |
| 2 | Création de la table cuisine | CREATE TABLE IF NOT EXISTS cuisine(idC INT PRIMARY KEY AUTO-INCREMENT, libelle VARCHAR(50)) |
| 3 | Creation de la table d'association restaurant_cuisine | CREATE TABLE IF NOT EXISTS restaurant_cuisine(idR int, idC int, PRIMARY KEY (idR, idC)) |
| 4 | Création et insertion des types de cuisine dans la table cuisine | INSERT INTO cuisine(libelle) VALUES ("sud ouest"), ("japonaise"), ("orientale"), ("fastfood"), ("vegetarienne"), ("vegan"), ("crepe"), ("sandwich"), ("tartes"), ("viande"), ("grillade"); |
| 5 | Ajout des cuisines à un restaurant via la table d'association | INSERT INTO restaurant_cuisine(idR, idC) VALUES(1, 10), (1, 11), (1, 1), (2, 10), (2, 11), (3, 2), (3, 5), (3, 6), (4, 7), (5, 3), (5, 4), (6, 1), (6, 10), (6, 8), (7, 1), (7, 4), (8, 3), (9, 10), (9, 11), (10, 8), (10, 9), (10, 4), (11, 3), (11, 11);
| 6 | Passer la colonne id_cuisine de la table cuisine en NOT NULL | ALTER TABLE cuisine MODIFY idC INT NOT NULL; |
| 7 | Passer les colonnes id_cuisine et idR de la table restaurant_cuisine en NOT NULL | ALTER TABLE restaurant_cuisine MODIFY idR INT NOT NULL, MODIFY idC INT NOT NULL; |
| 8 | Ajout de la contrainte de clé étrangère de la table proposer pour id_cuisine | ALTER TABLE restaurant_cuisine ADD CONSTRAINT fk_cuisine FOREIGN KEY (idC) REFERENCES cuisine(idC); |
| 9 | Verrouiller | Ajout de la contrainte de clé étrangère de la table proposer pour idR | ALTER TABLE restaurant_cuisine ADD CONSTRAINT fk_restaurant FOREIGN KEY (idR) REFERENCES resto(idR); | 
| 10 | Faire un état final en recherchant un restaurant et ses types de cuisine | SELECT r.nomR, c.libelle FROM resto as r INNER JOIN restaurant_cuisine ON r.idR = restaurant_cuisine.idR INNER JOIN cuisine as c ON c.idC = restaurant_cuisine.idC WHERE c.libelle = "viande" OR c.libelle = "japonaise";

