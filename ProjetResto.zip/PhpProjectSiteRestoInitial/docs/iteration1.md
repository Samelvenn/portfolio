# Itération 1 — Bilan de l’équipe [à compléter]

## Équipe et objectif

- Membres : Galahad Hervouet, Elven Lecorre-Peneau, Adam Zaamoun
- Animateur du point d’équipe : Galahad Hervouet
- Lien du dépôt / Milestone :https://gitlab.com/projet_ap_1/p1_g8_siteresto2026
- Objectif à 18h : Terminer les 5 issues
- Répartition initiale :
    - I1-01 : Galahad Hervouet
    - I1-02 : Adam Zaamoun
    - I1-03 : Elven Lecorre-Peneau
    - I1-04 : Galahad Hervouet
    - I1-05 : Adam Zaamoun

## Point d’équipe

| Heure | Obstacle ou information | Décision | Qui agit ? |
| --- | --- | --- | --- |
| 15:40| I1-02 terminé |Lancer une merge request| Adam Zaamoun |
|15:40| I1-03 terminé|Lancer une merge request|Elven Lecorre-Peneau|
|15:40|I1-05 terminé|Lancer une merge request|Adam Zaamoun|
|15:40|Modification assignation I1-04|Elven Lecorre-Peneau  --> Galahad Hervouet|Galahad Hervouet|

## Installation

- Procédure : voir README.
- Vérification par chaque équipier :

| Équipier | Environnement (OS, PHP, MariaDB) | Date | Résultat | Écarts par rapport au README |
| --- | --- | --- | --- | --- |
| Adam |  Windows,php 8.5.10,  mariadb 10.4.32 | 21/09/2026 | X | changer la ligne 25 Bdd.class.php |
| Galahad | Windows,php 8.5.10, mariadb 10.4.32 | 05/10/2026 | X | X |
| Elven | Windows,php 8.5.10,  mariadb 10.4.32 | 28/09/2026 | X | X |


- URL et preuve de lancement :

    - Commande : `php -S localhost:8000` (dossier contenant `index.php`).
    - `http://localhost:8000/` : accueil affiché avec le « Top 4 des meilleurs restaurants » (l'entrepote, Cidrerie du fronton, le bar du charcutier, la petite auberge).
    - `http://localhost:8000/index.php?action=liste` : … (à compléter après test)
    - Fiche d'un restaurant : URL … (à compléter après test)
    - Captures : `docs/captures/` (URL visible dans la barre d'adresse).

- Difficultés rencontrées et résolution :

| Symptôme | Cause | Résolution |
| --- | --- | --- |
| `mariadb` non reconnu dans PowerShell | Dossier `bin` de MariaDB absent du `Path` | Ajout au `Path` et ouverture d'un nouveau terminal |
| `Undefined constant PDO::MYSQL_ATTR_INIT_COMMAND` | Extension `pdo_mysql` désactivée | Activation de `extension=pdo_mysql` dans `C:\php\php.ini`, puis relance du serveur |
| `Access denied for user 'resto_util'@'localhost'` | Compte applicatif absent ou incohérent avec `Bdd.class.php` | Compte recréé avec le mot de passe de démonstration (voir ci-dessous) |
| `#1030 erreur 176 "Read page with wrong checksum"` (Aria) | Tables système de MariaDB corrompues | … (préciser : `REPAIR TABLE`, `aria_chk` ou autre) |
| `#1396 Operation CREATE USER failed` | Le compte `resto_util`@`localhost` existait déjà | `DROP USER IF EXISTS`, puis `CREATE USER` et `GRANT` sur `resto2.*` ; connexion vérifiée |
| `Deprecated: Constant PDO::MYSQL_ATTR_INIT_COMMAND` | PHP 8.5 : constante dépréciée dans `Bdd.class.php` | Non bloquant. Réglages relevés : `error_reporting = 30719`, `display_errors = 1`. Correction : … (Issue #NUMERO, ou « non corrigée ») |

## Tests fonctionnels

Renseigner l’attendu avant de conclure. Distinguer défaut du logiciel et problème d’environnement.

| Scénario | Action et données | Attendu | Observé | Conclusion / preuve |
| --- | --- | --- | --- | --- |
| Accueil | Ouvrir index.php et observer les restaurants affichés | On devrait pouvoir observé les restaurants qui sont en page d'accueil | On observe la présence de 4 restaurants qui sont à l'affiche sur l'accueil | La scénario accueil est fonctionnel |
| Liste | Ouvrir index.php?action=liste | On devrait pouvoir avoir la liste des restaurants présents dans la base de donnée | On observe un onglet avec la liste de tout les restaurants | Le scénario liste est fonctionnel |
| Fiche | Ouvrir une fiche depuis la liste et relever son URL | On devrait pouvoir accéder à la fiche d'information d'un restaurant et que son URL corresponde | On accède bien à la fiche spécifique du restaurant et son URL correspond à l'id du restaurant dans la base de données | Le scénario fiche est fonctionnel |
| Recherche, nom présent | Chercher un nom présent | On devrait pouvoir consulter la fiche du restaurant rechercher | On obtient le résultat et l'on peut consulter la fiche du restaurant | Le scénario recherche, nom présent est fonctionnel |
| Recherche, nom absent | Chercher un nom non présent | On devrait ne pas trouver de restaurant dans la liste | Aucun restaurant n'a été trouvé | Le scénario recherche, nom non présent est fonctionnel |
| Action inconnue | Ouvrir index.php?action=blob et observer la réponse | Action inconnue, donc pas possible de savoir ce qui doit être prévu | Affichage de la page d'accueil | Le scénario action inconnue est fonctionnel |

## Parcours MVC

- Valeur de `$fichier` et justification : La valeur de '$fichier' est celle de l'action, c'est à dire en fonction de quel élément est actionné sur la page, lorque le logo est activé on va à l'accueil.
- Schéma (insérer une image ou un diagramme ; distinguer appels et retours) : Voir le fichier nommé I1-T3_schema.png dans le dossier captures.
- Rôle des dossiers : Modele/dao sert à stocker les fichiers qui permettent d'accéder à la base de donnée, Modele/metier sert à stocker les différentes fonctionnalités codé tel que la critique ou les photos, c'est là où sont stockées les méthodes du code que l'on utilise et Modele/vue sert à stocker les différentes vues de l'application web, cela gère l'affichage donc par exemple l'accueil ou bien la page profil.
- Méthode, SQL et variable de la vue : La méthode getAll(), la requête est "SELECT * FROM resto" et la variable reçue par la vue est "$listesResto".
- Chargement automatique : Le fichier qui s'occupe automatiquement de ça est le fichier autoload.inc.php
- Observations ciblées du DAO et comparaison avec la base : La première méthode sert à identifier un seul restaurant tandis que l'autre méthode sert à obtenir la liste.

## Données

| Table | Clé primaire | Clés étrangères et tables visées |
| --- | --- | --- |
| utilisateur |idU | |
| resto |idR | |
| aimer |idR, idU |idR -> resto, idU -> utilisateur |
| critiquer |idR, idU |idR -> resto, idU -> utilisateur |

- Explication des relations : un utilisateur peut critiquer un restaurant ; un utilisateur peut noter(aimer) un restaurant
- Résultat de `sql/iteration1_requetes.sql` et commentaire :
|nomR|note|mailU|
|l'entrepote|3|jj.soueix@gmail.com|
|le bar du charcutier|2|jj.soueix@gmail.com|

L'utilisateur 'jj.soueix@gmail.com' est allé et a noté 2 restaurants : l'entrepote et le bar du charcutier

- Comparaison resto1 / resto2 et intérêt des contraintes :
Utilisateur a un ID dans resto2, utile pour éviter les répétitions dans une clé primaire
idU permet de garantir l'unicité car il devrait être impossible d'y retrouver un doublon contrairement à MailU.
Dans resto1, si l'adresse mail d'un utilisateur change, les autres tables sont affectées et les enregistrements comportant cette adresse mail deviennent corrompus. 

## Première contribution

- Issue / branche / MR : I1-02 Installer et lancer le site / I1-02 / I1-02

- Auteur / relecteur : ZAAMOUN Adam / Elven LECORRE-PENEAU

| Page | Résultat attendu | Résultat observé | Testé par |
| --- | --- | --- | --- |
| Accueil | Affiche la page d'accueil | la page d'accueil est afficher | ZAAMOUN Adam |
| Liste | Affiche la liste des restaurants | la liste des restaurants est afficher | Elven LECORRE-PENEAU |
| Fiche | Affiche la fiche du restaurant | la fiche du restaurant est afficher | ZAAMOUN Adam |

## Livraison et rétrospective

- Résultats démontrables :
- Anomalies reproduites et liens vers les Issues :
- Reste à faire :
- Tag / Release :
- Capture Git Graph commentée :
- Un point positif :
- Une difficulté :
- Une amélioration concrète pour la prochaine séance :

## Approfondissement facultatif

À compléter uniquement si réalisé : script séparé, contrôles avant/après et preuves.
