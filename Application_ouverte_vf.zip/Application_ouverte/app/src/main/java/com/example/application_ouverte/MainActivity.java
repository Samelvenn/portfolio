package com.example.application_ouverte;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button buttonFormulaireEntrainement;
    private Button buttonConsulterEntrainement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        buttonConsulterEntrainement = findViewById(R.id.buttonConsulterEntrainement);
        buttonFormulaireEntrainement = findViewById(R.id.buttonFormulaireEntrainement);
        buttonFormulaireEntrainement.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, FormulaireEntrainement.class);
            startActivity(intent);
        });
        buttonConsulterEntrainement.setOnClickListener(view -> {
            Intent intentListe = new Intent(MainActivity.this, ConsulterListeEntrainement.class);
            startActivity(intentListe);
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}