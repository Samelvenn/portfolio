<footer>
    <p>&copy; Mise à jour par l'equipe 8</p>
</footer>

</div>

</body>
</html>