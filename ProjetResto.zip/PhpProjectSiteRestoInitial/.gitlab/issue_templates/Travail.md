## Besoin / objectif

À compléter à partir du sujet et des échanges avec l’enseignant.

## Critères de validation

- [ ] …

## Organisation

- Responsable :
- Priorité discutée avec l’équipe / l’enseignant :
- Milestone :

## Preuves et suivi

- Branche / MR (si modification de fichier) :
- Tests et résultats :
- Obstacles / décision du point d’équipe :

Fermer après validation ; conserver ouverte si les critères ne sont pas atteints.
