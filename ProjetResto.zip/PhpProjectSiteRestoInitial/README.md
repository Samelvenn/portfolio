# PhpProjectSiteResto

AP 2SLAM - projet du premier semestre
Contexte
site r3st0.fr,site de critique (Cf. lafourchette, tripadvisor, etc.)
Sujet tiré d'une production du CERTA https://www.reseaucerta.org/decouverte-mvc-et-acces-aux-donnees-dans-une-application-web-en-php


---

## Démarrage — promotion 2026–2027

Ce guide complète les crédits ci-dessus. Complétez-le avec les versions et les paramètres de votre environnement, sans publier de secrets personnels.

### 1. Vérifier l’environnement

Travaillez dans votre VM de développement. Ouvrez dans VS Code ou NetBeans le dossier contenant `index.php`.

```sh
php -v
php -m
mariadb --version
git --version
```

PHP doit fournir `PDO` et `pdo_mysql`. MariaDB doit être démarré. Si un outil manque ou si vous ne disposez pas des droits nécessaires, sollicitez l’enseignant. Le projet ne nécessite ni Composer, ni npm, ni serveur Java. Le réglage NetBeans d’origine indique PHP 7.4 : adaptez la version de langage de l’IDE au PHP réellement installé, sans installer une ancienne version pour cette seule raison.

### 2. Importer la base utilisée par le site

Utilisez votre client SQL habituel avec un compte d’administration local. Sur une installation neuve, exécutez dans cet ordre :

1. `sql/resto2.sql` — crée et sélectionne `resto2`, puis importe les tables et les données ;
2. `sql/resto_create_utilisateur.sql` — crée le compte applicatif de démonstration et ses droits.

Exemple en terminal, si votre VM autorise l’administration MariaDB par `sudo` :

```sh
sudo mariadb < sql/resto2.sql
sudo mariadb < sql/resto_create_utilisateur.sql
```

Avec un compte administrateur nommé, utilisez `mariadb -u NOM_ADMIN -p` et l’import de votre client ; saisissez le mot de passe à l’invite. Ces commandes ne sont pas obligatoires si vous utilisez une interface SQL graphique.

**Ne relancez pas les scripts sur une base déjà utilisée.** Le script utilisateur n’est pas réexécutable tel quel si `resto_util@localhost` existe. Dans ce cas, vérifiez ses droits et utilisez les paramètres connus avec l’enseignant. Ne supprimez pas une base pour contourner une erreur d’import.

### 3. Contrôler la connexion

Dans `modele/dao/Bdd.class.php`, les valeurs livrées sont :

| Paramètre | Valeur pédagogique |
| --- | --- |
| Serveur | `localhost` |
| Base | `resto2` |
| Utilisateur | `resto_util` |
| Mot de passe de démonstration | `secret` |

Le mot de passe `secret` est commun au script de cours ; il ne doit pas être réutilisé pour un service exposé. Si votre environnement impose un secret personnel, demandez à l’enseignant comment le configurer sans le committer. Vérifiez le contenu de `git diff` avant chaque commit.

### 4. Lancer le site

Dans le dossier contenant `index.php` :

```sh
php -S localhost:8000
```

Laissez le terminal ouvert. Dans le navigateur **de la même VM**, ouvrez `http://localhost:8000/`, puis la liste et une fiche. Commencez avec une session de navigation vierge. Arrêtez le serveur avec `Ctrl+C`. Si le port 8000 est occupé, utilisez par exemple 8001 et adaptez l’URL.

Le serveur intégré sert aux essais locaux. L’extension VS Code « Live Server » ne remplace pas un serveur PHP. Ne double-cliquez pas sur `index.php`.

### 5. Travailler en équipe

- Créer les cinq Issues et le Milestone à partir du sujet, puis attribuer les responsabilités.
- Pour chaque contribution : branche issue de `dev` à jour, commits précis, actualisation de `dev` dans la branche, tests, push, MR vers `dev`, relecture par un équipier.
- Utiliser `Refs #NUMERO` avec le numéro GitLab réel. Fermer l’Issue après validation et intégration.
- Les modèles `.gitlab/issue_templates/Travail.md` et `.gitlab/merge_request_templates/Contribution.md` sont disponibles dans GitLab après leur premier push.
- À la livraison : MR `dev` vers `main`, conserver `dev` et son historique, puis tag `v0.1.0` et Release.

Se référer aux deux documents Git/GitLab déjà étudiés pour les manipulations détaillées.

### 6. Compléter les livrables

- `docs/iteration1.md` : équipe, décisions, tests, MVC, analyse et bilan.
- `sql/iteration1_requetes.sql` : requête demandée à écrire et exécuter.
- `docs/captures/` : preuves utiles, sans mots de passe ni données personnelles ajoutées.
- Le présent README : préciser votre procédure et vérifier qu’un équipier peut la reproduire.

Les scripts historiques dans `tests/` sont des essais manuels. Certains exercent des fonctions incomplètes ou peuvent modifier les données. Lisez-les avant exécution ; suivez les deux appels ciblés demandés dans le sujet.

### Informations à renseigner par l’équipe

- Membres et identifiant d’équipe : Groupe 8 ; Adam ZAAMOUN, Elven LECORRE-PENEAU, Galahad HERVOUET
- Versions PHP / MariaDB / système : php 8.5.10,  mariadb 10.4.32
- Procédure réellement testée et éventuels écarts : …
- Date et équipier ayant reproduit l’installation : …

### Dépannage

| Message ou symptôme | Vérification |
| --- | --- |
| `could not find driver` | Vérifier `pdo_mysql` dans le PHP du terminal |
| `Access denied` | Vérifier compte, hôte, mot de passe et droits |
| `Unknown database` | Vérifier l’import et le nom de base |
| `Table already exists` | Examiner la base existante avant de réimporter |
| Code PHP affiché / téléchargement | Utiliser une URL HTTP servie par PHP |
| Port occupé | Arrêter l’ancien serveur ou changer de port |

Référence de lancement : https://www.php.net/manual/fr/features.commandline.webserver.php


### Documentation Ticket I2-11

Besoin : après s’être connecté, un utilisateur doit conserver un état de connexion cohérent lorsqu’il navigue entre l’accueil, la liste et une fiche, puis pouvoir se déconnecter.

| Tests réalisés | Validation|
| :---: | :---: |
| La connexion avec le compte de test (test@bts.sio) fonctionne. | ✔ |
| Changer de page plusieurs fois ne cause pas une déconnection. | ✔ |
| Changer de page plusieurs fois ne cause pas une déconnection. | ✔ |
| La déconnexion du compte de test (test@bts.sio) fonctionne. | ✔ |
| Après déconnexion, les actions réservées aux comptes connectés ne sont plus accessibles, comme le fait de critiquer un restaurant ou retirer sa critique. | ✔ |
| Un visiteur non connecté peut tout de même accéder aux pages publiques. | ✔ |
| Utiliser n'importe quel lien menant au site quand connecté va nous mettre sur le site connecté | ✔ |
| Utiliser n'importe quel lien menant au site quand non connecté va nous mettre sur le site non connecté | ✔ |
| Avoir 2 onglets et déconnecter un des 2 onglets puis naviguer sur l'autre onglet va instantanément déconnecter le deuxième onglet | ✔ |

Méthode de connexion :

- fonction isLoggedOn de Authentification.inc.php définit si oui ou non un utilisateur est connecté (Utilise des cookies de session).

- Dans Connexion.php, on appelle la fonction isLoggedOn pour vérifier si l'utilisateur est connecté à tout changement de page et applique le statut actuel de l'utilisateur à la page chargée.

Conclusion du ticket

La connexion est non seulement stable, mais aussi sécurisée
