# R3st0 — Archive de démarrage · Itération 1

Séance du 21 septembre 2026, 14h–18h · BTS SIO 2e année SLAM.

## Commencer

1. Extraire entièrement cette archive.
2. Lire le sujet étudiant « Première séance — Reprise du projet existant » distribué séparément.
3. Un membre initialise le dépôt GitLab de l’équipe avec **le contenu de `PhpProjectSiteRestoInitial/`**, fichiers cachés compris. `index.php` doit se trouver à la racine du dépôt. Ne pas importer le dossier parent de cette archive.
4. Après le premier commit sur `main`, créer `dev`. Les autres membres clonent le dépôt commun.
5. Suivre le `README.md` du projet pour importer **resto2** et lancer le site. Chaque étudiant possède sa base locale.

## Contenu

| Emplacement | Usage |
| --- | --- |
| `PhpProjectSiteRestoInitial/` | Site PHP, scripts resto2, tests d’origine et fichiers de travail à compléter |
| `ressources/resto1/` | Ancien modèle SQL à comparer ; migration facultative |
| `VERIFICATION.md` | Périmètre et résultats des contrôles effectués sur cette archive |
| `MANIFEST_SHA256.txt` | Empreintes des fichiers du paquet, avant modification par l’équipe |

Le site est une version pédagogique à diagnostiquer et à maintenir. « Vérifiée » signifie que le périmètre de démarrage indiqué dans le rapport a été contrôlé ; cela ne signifie pas que toutes les fonctionnalités sont correctes. Le code métier, les vues, les ressources et les données livrés initialement sont conservés.

Les modèles facilitent la prise de notes sans donner les réponses : la requête SQL, le schéma MVC, les observations et la mention d’équipe restent à réaliser. Les anomalies découvertes seront discutées avec l’enseignant pour les itérations suivantes.

NetBeans et VS Code sont autorisés. Aucun projet Git, compte GitLab, branche ou ticket n’est précréé dans cette archive.
