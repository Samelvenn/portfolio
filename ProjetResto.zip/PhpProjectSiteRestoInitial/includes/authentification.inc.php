<?php

use modele\dao\UtilisateurDAO;

/* * ******************************************************************
 * Fonctions de gestion de l'authentification à l'aide des sessions
 * 
 * @version 07/2021 par NB : intégration couche modèle objet
 * 
 * ******************************************************************* */

/**
 * Authentifier un utilisateur et ouvrir sa session
 * @param string $mailU adresse mail de connexion saisie par l'utilisateur
 * @param string $mdpU  mot de passe saisi par l'utilisateur
 */
/**
 * Authentifier un utilisateur et ouvrir sa session
 * @param string $mailU adresse mail de connexion saisie par l'utilisateur
 * @param string $mdpU mot de passe saisi par l'utilisateur
 */
function login(string $mailU, string $mdpU): void {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    // Rechercher les données relatives à cet utilisateur
    $util = UtilisateurDAO::getOneByMail($mailU);
    
    // Si l'utilisateur est connu (mail trouvé dans la BDD)
    if (!is_null($util)) {
        $mdpBD = $util->getMdpU();
        $idU = $util->getIdU(); // Utilise la vraie méthode de ton objet (souvent getIdU())
        
        $connexionValidee = false;
        
        // 1. Vérification avec le nouveau système (password_verify)
        if (password_verify($mdpU, $mdpBD)) {
            $connexionValidee = true;
        } 
        // 2. Fallback : Vérification avec l'ancien système (crypt) pour les comptes existants
        elseif (trim($mdpBD) === trim(crypt($mdpU, $mdpBD))) {
            $connexionValidee = true;
            
            // MIGRATION: On met à jour le mot de passe avec le nouveau hachage sécurisé
            $nouveauHash = password_hash($mdpU, PASSWORD_DEFAULT);
            
            // Appel direct à la méthode de mise à jour ou requête DAO existante
            UtilisateurDAO::updateMdp($idU, $nouveauHash); 
        }
        
        if ($connexionValidee) {
            // Le mot de passe est correct, on ouvre la session
            $_SESSION["idU"] = $idU;
            $_SESSION["mailU"] = $mailU;
        }
    }
}

/**
 * Fermeture de la session de connexion
 * @return void
 */
function logout(): void {
    if (!isset($_SESSION)) {
        session_start();
    }
    unset($_SESSION["idU"]);
    unset($_SESSION["mailU"]);
    // unset($_SESSION["mdpU"]);
}

/**
 * Identité de l'utilisateur connecté
 * @return string mail de l'utilisateur connecté ou "" si aucun
 */
function getMailULoggedOn(): string {
    if (isLoggedOn()) {
        $ret = $_SESSION["mailU"];
    } else {
        $ret = "";
    }
    return $ret;
}

/**
 * Identité de l'utilisateur connecté
 * @return int id de l'utilisateur connecté ou 0 si aucun
 */
function getIdULoggedOn(): int {
    if (isLoggedOn()) {
        $ret = intval($_SESSION["idU"]);
    } else {
        $ret = 0;
    }
    return $ret;
}

/**
 * Vérifie si l'utilisateur courant ($util) est bien connecté
 * @return bool = true s'il est bien connecté ; =false sinon
 */
function isLoggedOn(): bool {
    if (!isset($_SESSION)) {
        session_start();
    }
    $ret = false;

    if (isset($_SESSION["idU"]) && isset($_SESSION["mailU"])) {
        $util = UtilisateurDAO::getOneById($_SESSION["idU"]);
        // On vérifie que l'utilisateur existe et que l'e-mail correspond
        if (!is_null($util) && $util->getMailU() == $_SESSION["mailU"]) {
            $ret = true;
        }
    }
    return $ret;
}
