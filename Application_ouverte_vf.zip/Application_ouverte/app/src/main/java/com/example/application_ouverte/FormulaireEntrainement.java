package com.example.application_ouverte;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FormulaireEntrainement extends AppCompatActivity {

    private EditText editTextCoach;
    private EditText editTextBalle;
    private EditText editTextNbParticipants;
    private EditText editTextDuree;

    private RadioGroup radioGroupCours;
    private Button buttonConsulter;
    private Button buttonRetourAccueil;

    public static final String EXTRA_Coach = "extraCoach";
    public static final String EXTRA_BALLE = "extraBalle";
    public static final String EXTRA_PARTICIPANTS = "extraParticipants";
    public static final String EXTRA_DUREE = "extraDuree";
    public static final String EXTRA_COURS = "extraCours";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_formulaire_entrainement);
        editTextCoach = findViewById(R.id.editTextCoach);
        editTextBalle = findViewById(R.id.editTextBalle);
        editTextNbParticipants = findViewById(R.id.editTextNbParticipants);
        editTextDuree = findViewById(R.id.editTextDuree);
        radioGroupCours = findViewById(R.id.radioGroupCours);
        buttonRetourAccueil = findViewById(R.id.buttonRetourAccueil);
        buttonConsulter = findViewById(R.id.buttonConsulter);
        buttonRetourAccueil.setOnClickListener(view -> finish());
        buttonConsulter.setOnClickListener(view -> {
            String nomCoach = editTextCoach.getText().toString().trim();
            String nomBalle = editTextBalle.getText().toString().trim();
            String nombreParticipants = editTextNbParticipants.getText().toString().trim();
            String dureeSaisie = editTextDuree.getText().toString().trim();

            if (nomCoach.isEmpty()) {
                editTextCoach.setError(
                        "Saisissez le nom du coach");
                return;
            }
            if (nomBalle.isEmpty()) {
                editTextBalle.setError(
                        "Saisissez le nom des balles");
                return;
            }

            if (dureeSaisie.isEmpty()) {
                editTextDuree.setError("Saisissez une durée en minutes");
                return;
            }
            int dureeMinutes = Integer.parseInt(dureeSaisie);
            if (dureeMinutes < 30 || dureeMinutes > 120) {
                editTextDuree.setError(
                        "La durée doit être comprise entre 30 et 120 minutes");
                return;
            }

            if (nombreParticipants.isEmpty()) {
                editTextDuree.setError("Saisissez un nombre de participants");
                return;
            }
            int Participants = Integer.parseInt(nombreParticipants);
            if (Participants < 1 || Participants > 6) {
                editTextDuree.setError(
                        "Le nombre de participants doit être supérieur à un et inférieur à 7");
                return;
            }

            int choix = radioGroupCours.getCheckedRadioButtonId();
            String cours;

            if (choix == R.id.radioButtonCoursA) {
                cours = "Cours A";
            } else if (choix == R.id.radioButtonCoursB) {
                cours = "Cours B";
            } else {
                cours = "Cours C";
            }

            Intent intentFormulaire = new Intent(FormulaireEntrainement.this, ConsulterFormulaire.class);
            intentFormulaire.putExtra(EXTRA_Coach, nomCoach);
            intentFormulaire.putExtra(EXTRA_BALLE, nomBalle);
            intentFormulaire.putExtra(EXTRA_DUREE, dureeMinutes);
            intentFormulaire.putExtra(EXTRA_COURS, cours);
            intentFormulaire.putExtra(EXTRA_PARTICIPANTS, Participants);
            startActivity(intentFormulaire);
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}