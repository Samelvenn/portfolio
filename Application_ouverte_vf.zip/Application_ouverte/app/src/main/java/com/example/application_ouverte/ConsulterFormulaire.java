package com.example.application_ouverte;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ConsulterFormulaire extends AppCompatActivity {

    private TextView textViewCoach;
    private TextView textViewBalle;
    private TextView textViewNbParticipants;
    private TextView textViewDuree;
    private TextView textViewCours;
    private Button buttonRetourFormulaire;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_consulter_formulaire);
        buttonRetourFormulaire = findViewById(R.id.buttonRetourFormulaire);
        textViewCoach = findViewById(R.id.textViewCoach);
        textViewBalle = findViewById(R.id.textViewBalle);
        textViewNbParticipants = findViewById(R.id.textViewNbParticipants);
        textViewDuree = findViewById(R.id.textViewDuree);
        textViewCours = findViewById(R.id.textViewCours);

        Intent intent = getIntent();
        String nomCoach = intent.getStringExtra(FormulaireEntrainement.EXTRA_Coach);
        String nomBalle = intent.getStringExtra(FormulaireEntrainement.EXTRA_BALLE);
        int nombreParticipants = intent.getIntExtra(FormulaireEntrainement.EXTRA_PARTICIPANTS,2);
        int duree = intent.getIntExtra(FormulaireEntrainement.EXTRA_DUREE,30);
        String cours = intent.getStringExtra(FormulaireEntrainement.EXTRA_COURS);

        textViewCoach.setText("Coach : " + nomCoach);
        textViewBalle.setText("Balle : " + nomBalle);
        textViewNbParticipants.setText("Nombre de participants : " + nombreParticipants);
        textViewDuree.setText("Duree de l'entrainement : " + duree + " minutes ");
        textViewCours.setText("Sur le " + cours);

        buttonRetourFormulaire.setOnClickListener(view -> finish());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}