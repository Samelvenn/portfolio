# Itération 2 — Bilan de l’équipe

## Équipe et objectif

- Membres : Galahad Hervouet, Elven Lecorre-Peneau, Adam Zaamoun
- Animateur du point d’équipe : Galahad Hervouet
- Lien du dépôt / Milestone :https://gitlab.com/projet_ap_1/p1_g8_siteresto2026
- Objectif : Terminer autant d'issues que possible

## Tickets et Merge Requests

- Ticket 03 - changement de la requête sql de la fonction getTop4 [#14]
- Ticket 11 - vérification de la connexion [#10]
- Ticket 02 - Moderniser le stockage des mots de passe [#13]
- Ticket 07 - Sécuriser les requêtes de connexion [#06]
- Ticket 08 - Changer le fonctionnement de la recherche par critères[#07]
- Ticket 05 - Vérification longueur code postal [#16]
- Ticket 09 - Ajout d'un message lors d'un retour de recherche vide[#08]
- Ticket 04 - Ajout de l'onglet 'Note Moyenne' pour les restaurants [#15]

## Vérifications


Tests réalisés :

# Ticket 11
La connexion avec le compte de test (test@bts.sio) fonctionne.
Changer de page plusieurs fois ne cause pas une déconnection.
Changer de page plusieurs fois ne cause pas une déconnection.
La déconnexion du compte de test (test@bts.sio) fonctionne.
Après déconnexion, les actions réservées aux comptes connectés ne sont plus accessibles, comme le fait de critiquer un restaurant ou retirer sa critique.
Un visiteur non connecté peut tout de même accéder aux pages publiques.
Utiliser n'importe quel lien menant au site quand connecté va nous mettre sur le site connecté
Utiliser n'importe quel lien menant au site quand non connecté va nous mettre sur le site non connecté
Avoir 2 onglets et déconnecter un des 2 onglets puis naviguer sur l'autre onglet va instantanément déconnecter le deuxième onglet

# Ticket 02
Récupérer la dernière version et la base de données :

Faire un git pull de la branche.
Importer le nouveau fichier SQL (Migration_mdpU.sql) mis à jour dans votre environnement local (phpMyAdmin).


Tester la connexion d'un compte existant (migration à la volée) :

Se connecter avec un compte préexistant (ex: test@bts.sio avec son mot de passe d'origine).
Résultat attendu : La connexion réussit. En vérifiant dans la base de données, le champ mdpU de ce compte s'est transformé en un hachage long.


Tester un nouveau compte :

Créer un nouveau compte via le formulaire d'inscription.
Vérifier en base de données que le mot de passe est directement stocké sous forme de hachage sécurisé (aucun mot de passe en clair).
Se déconnecter, puis se reconnecter avec ce nouveau com

# Ticket 07
git pull de la branche.
Page Connexion, faire ces essais :

# Ticket 08
Aller sur la page d'accueil au niveau de la barre latérale et cliquer sur l'onglet recherche multicritère.
Choisir un restaurant à rechercher.
Tester un à un en ajoutant un critère à chaque fois. Normalement vous devriez trouver le même restaurant pour chaque recherche.

# Ticket 05
Aller sur une page de recherche grâce au menu latéral de la page d'accueil.
Tester avec le champ vide, avec 4 chiffres, avec 6 chiffres et avec une lettre.
Il faut tester les différents cas sur les deux recherches possédant un code postal : la recherche par adresse et la recherche multicritère.

# Ticket 09
Aller sur la page d'accueil et effectuer une recherche par nom.
Rechercher un nom qui n'existe pas comme Buffalo Grill.
Constater qu'un message apparait.
Tester sur les autres recherches.

# Ticket 04
Rechercher un restaurant.
Consulter sa fiche et voir un onglet note moyenne avec sa note.
Pour vérifier le cas où il n'y a pas de notes enregistrées, il faut rechercher le restaurant : Sapporo.