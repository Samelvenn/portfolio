package com.example.application_ouverte;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EntrainementAdapter extends RecyclerView.Adapter<EntrainementAdapter.EntrainementHolder> {

    private final ArrayList<Entrainement> entrainements;

    public EntrainementAdapter(ArrayList<Entrainement> entrainements) {
        this.entrainements = entrainements;
    }

    public static class EntrainementHolder extends RecyclerView.ViewHolder {
        final TextView textViewCoachRe;
        final TextView textViewBalleRe;
        final TextView textViewParticipantsRe;
        final TextView textViewDureeRe;
        final TextView textViewCoursRe;

        public EntrainementHolder(@NonNull View itemView) {
            super(itemView);
            textViewCoachRe = itemView.findViewById(R.id.textViewCoachRe);
            textViewBalleRe = itemView.findViewById(R.id.textViewBalleRe);
            textViewParticipantsRe = itemView.findViewById(R.id.textViewParticipantsRe);
            textViewDureeRe = itemView.findViewById(R.id.textViewDureeRe);
            textViewCoursRe = itemView.findViewById(R.id.textViewCoursRe);
        }
    }

    @NonNull
    @Override
    public EntrainementHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View Ligne = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entrainement, parent, false);
        return new EntrainementHolder(Ligne);
    }

    @Override
    public void onBindViewHolder(@NonNull EntrainementHolder holder, int position) {
        Entrainement entrainement = entrainements.get(position);
        holder.textViewCoachRe.setText("Coach : " + entrainement.getCoach());
        holder.textViewBalleRe.setText("Balle : " + entrainement.getBalle());
        holder.textViewParticipantsRe.setText(String.valueOf(entrainement.getNbParticipants()));
        holder.textViewDureeRe.setText(String.valueOf(entrainement.getDuree()));
        holder.textViewCoursRe.setText("Cours : " + entrainement.getCours());

        if ("Cours A".equals(entrainement.getCours())) {
            holder.textViewCoursRe.setTextColor(Color.RED);
        } else if ("Cours B".equals(entrainement.getCours())){
            holder.textViewCoursRe.setTextColor(Color.BLUE);
        } else {
            holder.textViewCoursRe.setTextColor(Color.GREEN);
        }

    }

    public int getItemCount() {
        return entrainements.size();
    }




}
